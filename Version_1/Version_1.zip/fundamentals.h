// FUNDAMENTALS MODULE HEADER
#ifndef _FUNDAMENTALS_H_
#define _FUNDAMENTALS_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void fundamentals (void);
#endif