// MANIPULATING MODULE HEADER
#ifndef _MANIPULATING_H_
#define _MANIPULATING_H_
#include <stdio.h>
#include <string.h>
void manipulating(void);
#endif
